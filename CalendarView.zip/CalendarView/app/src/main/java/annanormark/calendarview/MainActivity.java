package annanormark.calendarview;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.github.sundeepk.compactcalendarview.CompactCalendarView;
import com.github.sundeepk.compactcalendarview.domain.CalendarDayEvent;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    dbHandler datesOfDeadLines;
    Date selectedDate;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Context context = getApplicationContext();
        final TextView tex = (TextView) findViewById(R.id.annasText);
        final TextView DB = (TextView) findViewById(R.id.TestDB);
        final CompactCalendarView Cal = (CompactCalendarView) findViewById(R.id.Cal);

        final List<String> titles = new ArrayList<>();

        tex.setText(" ");
        DB.setText("");
        datesOfDeadLines = new dbHandler(this, null, null,1);

       // Toast.makeText(MainActivity.this, eventList.toString(), Toast.LENGTH_SHORT).show();
            //Makes the events show in the interface as dots when starting
        Cal.drawSmallIndicatorForEvents(true);
        List<Long> dates = datesOfDeadLines.getDates();
        for (int i = 0; i <dates.size(); i++){
            Cal.addEvent(new CalendarDayEvent(dates.get(i), Color.RED), false);
        }
        Cal.invalidate();



        /***********Sets listener for what happens when a new date is clicked in the calendar***************/
        Cal.setListener(new CompactCalendarView.CompactCalendarViewListener() {
            @Override
            public void onDayClick(Date dateClicked) {

                ListView eventList = (ListView) findViewById(R.id.eventList);
                selectedDate = dateClicked;
                tex.setText("" + selectedDate.getDate() + "/" + selectedDate.getMonth() + " ");
              //  DB.setText(datesOfDeadLines.eventsOfDatesToString(selectedDate.getTime()));
              //  titles.clear();
                String[] temp = datesOfDeadLines.getTitles(dateClicked.getTime());
                ListAdapter adapter = new customAdapter(getBaseContext(), datesOfDeadLines.getTitles(dateClicked.getTime()));
               // Toast.makeText(MainActivity.this, adapter.getItem(0).toString(), Toast.LENGTH_SHORT).show();
              /*  for(int i = 0; i < titles.size(); i++) {
                    titles.add(temp.get(i).toString());
                }*/
                assert eventList != null;
                eventList.setAdapter(adapter);


            }

            @Override
            public void onMonthScroll(Date firstDayOfNewMonth) {
                //  actionBar.setTitle(dateFormatForMonth.format(firstDayOfNewMonth));
            }
        });


    }

    /*************** clicked button "add event", starts activity "makeDeadLine" *****************/
    public void addDeadLine(View view){
        Context context = getApplicationContext();
        if (selectedDate==null) {
            Toast.makeText(context, "Select a date", Toast.LENGTH_LONG).show();
            return;
        }

        Intent i = new Intent(this, makeDeadLine.class);
        i.putExtra("Time", selectedDate);
        startActivity(i);

    }


















 /*   @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }*/
}
