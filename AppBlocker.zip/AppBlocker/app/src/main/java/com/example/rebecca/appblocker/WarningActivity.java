package com.example.rebecca.appblocker;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.WindowManager;
//import android.widget.TextView;

public class WarningActivity extends AppCompatActivity {

    //private TextView warning_text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_warning);

      //  warning_text = (TextView) findViewById(R.id.warningText);

    }
}
