package com.example.rebecca.appblocker;

/**
 * Created by Rebecca on 16-04-26.
 */
import android.app.usage.UsageStats;
import android.util.Pair;

import java.util.ArrayList;
import java.util.List;



public class AppStatistics {

    public String appName;
    public Long appTime;

    public AppStatistics(String app, Long time) {
            this.appName = app;
            this.appTime = time;
    }

    public Long getAppTime() {
        return appTime;
    }

    public String getAppName() {
        return appName;
    }
}
