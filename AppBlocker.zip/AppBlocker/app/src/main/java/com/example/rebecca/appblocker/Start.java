package com.example.rebecca.appblocker;


import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.provider.Settings;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.rebecca.appblocker.service.CoreService;
import com.example.rebecca.appblocker.Utils.BlockUtils;
import com.example.rebecca.appblocker.Utils.TopActivityUtils;


public class Start extends AppCompatActivity implements View.OnClickListener {

    private static final int REQUEST_SETTING = 1;


    private Button blockList, start;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);

        blockList = (Button) findViewById(R.id.blockListButton);
        start = (Button) findViewById(R.id.startBlockButton);

        blockList.setOnClickListener(this);
        start.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v == blockList) {
            if (!TopActivityUtils.isStatAccessPermissionSet(this)) {
                showDialog();
            } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
                    Intent intent = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
                    intent.setClass(this, AppList.class);
                    startActivity(intent);
                } else {
                    Intent intent = new Intent();
                    intent.setClass(this, AppList.class);
                    startActivity(intent);
                }
            }
        }
        else if (v == start) {
            if (BlockUtils.isBlockServiceRunning(this,
                    CoreService.class)) {
                Intent intent = new Intent();
                intent.setClass(this, CoreService.class);
                this.stopService(intent);
                start.setText(R.string.start_block);
            }
            else {
                if (!TopActivityUtils.isStatAccessPermissionSet(this)) {
                    showDialog();

                } else {
                    Intent intent = new Intent();
                    intent.setClass(this, CoreService.class);
                    this.startService(intent);
                    start.setText(R.string.stop_block);
                }
            }

        }


    }

    private void showDialog() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.dialog_title)
                .setMessage(R.string.dialog_message)
                .setPositiveButton(R.string.dialog_ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {

                        //some rom has removed the newly introduced android.settings.USAGE_ACCESS_SETTINGS
                        try {
                            startActivityForResult(new Intent("android.settings.USAGE_ACCESS_SETTINGS"), REQUEST_SETTING);
                        } catch (Exception e) {
                            dialog.dismiss();
                        }
                    }
                })
                .setNegativeButton(R.string.dialog_no, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                })
                .show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_SETTING) {
            if (TopActivityUtils.isStatAccessPermissionSet(this)) {
                //成功开启了权限

                Intent intent = new Intent();
                intent.setClass(this, CoreService.class);
                this.startService(intent);
                start.setText(R.string.stop_block);

                Toast.makeText(this, R.string.permission_ok, Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, R.string.permission_error, Toast.LENGTH_LONG).show();
            }
        }
    }
}
