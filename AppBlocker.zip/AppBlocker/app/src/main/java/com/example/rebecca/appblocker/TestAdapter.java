package com.example.rebecca.appblocker; /**
 * Created by Rebecca on 16-04-23.
 */


import android.content.Context;
import android.content.pm.PackageInfo;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
//import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.rebecca.appblocker.R;

import java.util.*;

public class TestAdapter extends ArrayAdapter<String>{

   //private List<PackageInfo> installedAppsList = null;
   //private


    public TestAdapter(Context context, String[] foods) {
        super(context, R.layout.list_item,foods);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        LayoutInflater blockListInflater = LayoutInflater.from(getContext());
        View blockListView = blockListInflater.inflate(R.layout.list_item, parent, false);
        //Refrence to string, supposing maybe app list?
        String singleFoodItem = getItem(position);
        TextView appName = (TextView) blockListView.findViewById(R.id.app_name);
        ImageView icon = (ImageView) blockListView.findViewById(R.id.app_icon);

        appName.setText(singleFoodItem);
        //instead of ic_info..., app icon. Collect from applist?
        icon.setImageResource(R.drawable.ic_info_black_24dp);
        return blockListView;

    }
}
